import React,{useEffect} from "react";
import Aboutcontent from '../components/pages/about/Aboutcontent';
// import Aboutcontent from './Aboutcontent';
import AOS from 'aos';
import 'aos/dist/aos.css';
function About() {
    return (
        <>
        <Aboutcontent/>
        </>
    );
}

export default About;
